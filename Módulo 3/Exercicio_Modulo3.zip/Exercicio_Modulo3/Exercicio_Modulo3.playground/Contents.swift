import UIKit

var str = "Hello, playground"

var idadeCarlos: Int = 30
var idadeRebeka: Int = 24
var SomadasIdades = idadeCarlos + idadeRebeka

print(SomadasIdades)

