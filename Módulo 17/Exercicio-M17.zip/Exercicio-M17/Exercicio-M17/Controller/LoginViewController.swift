//
//  LoginViewController.swift
//  Exercicio-M17
//
//  Created by Kleiton Mendes on 19/07/22.
//

import Foundation
import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
}
    
    @IBAction func conectarButton(_ sender: UIButton) {
        
    }
    
    @IBAction func esqueceuSenhaButton(_ sender: UIButton) {
    }
    
}
