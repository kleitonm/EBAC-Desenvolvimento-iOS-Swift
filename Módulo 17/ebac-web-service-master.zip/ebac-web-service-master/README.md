### Course EBAC Swift - Repo with backend

##### Content of this repository for the URLSession, Request, Download, and Uploading files.