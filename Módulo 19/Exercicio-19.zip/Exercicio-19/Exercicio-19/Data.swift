//
//  Data.swift
//  Exercicio-19
//
//  Created by Kleiton Mendes on 28/08/22.
//

import Foundation

let urlDownloads = ["https://slik.com.br/wp-content/uploads/2022/04/como-montar-um-setup-produtivo.jpg",
"https://tm.ibxk.com.br/2022/03/17/17113400495280.jpg?ims=704x264",
"https://meusetup.com/rails/active_storage/representations/proxy/eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaHBBcFVGIiwiZXhwIjpudWxsLCJwdXIiOiJibG9iX2lkIn19--01db650cb7891ba05a50f9c765a633f06f54deba/eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaDdDVG9MWm05eWJXRjBTU0lJU2xCSEJqb0dSVlE2RkhKbGMybDZaVjkwYjE5c2FXMXBkRnNIYVFLRUEya0NoQU02REdkeVlYWnBkSGxKSWc1VGIzVjBhRVZoYzNRR093WlVPZ2xrY21GM1NTSkRhVzFoWjJVZ1QzWmxjaUF3TERBZ01Dd3dJQ0l2WVhCd0wyeHBZaTloYzNObGRITXZhVzFoWjJWekwzQmhhV1F0ZDJGMFpYSnRZWEpyTG5CdVp5SUdPd1pVIiwiZXhwIjpudWxsLCJwdXIiOiJ2YXJpYXRpb24ifX0=--e091ca0bf5755ef67ecae332cc4dab4bfad70175/DSC01419.JPG"]
