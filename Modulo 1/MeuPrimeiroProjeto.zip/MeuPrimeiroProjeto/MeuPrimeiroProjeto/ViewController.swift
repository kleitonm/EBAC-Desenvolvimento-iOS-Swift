//
//  ViewController.swift
//  MeuPrimeiroProjeto
//
//  Created by Kleiton Mendes on 09/09/2021.
//  Copyright © 2021 Kleiton Mendes. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //MARK: - ViewDidload
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view, typically from a nib.
    }

    //MARK: - function COlor Change
    

}

